import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Signup from './components/Signup';
import Dashboard from './components/Dashboard';
import Lesson from './components/Lesson';
import Quiz from './components/Quiz';
import Chatbot from './components/Chatbot';

function App() {
  const isAuthenticated = !!localStorage.getItem('token');

  return (
    <div>
      <Routes>
        <Route path="/" element={isAuthenticated ? <Navigate to="/dashboard" /> : <Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/dashboard" element={isAuthenticated ? <Dashboard /> : <Navigate to="/" />} />
        <Route path="/lesson/:id" element={isAuthenticated ? <Lesson /> : <Navigate to="/" />} />
        <Route path="/quiz" element={isAuthenticated ? <Quiz /> : <Navigate to="/" />} />
        <Route path="/chat" element={isAuthenticated ? <Chatbot /> : <Navigate to="/" />} />
      </Routes>
    </div>
  );
}

export default App;
