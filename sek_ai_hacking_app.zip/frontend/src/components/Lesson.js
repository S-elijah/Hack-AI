import React, { useEffect, useState } from 'react';
import { fetchLesson } from '../services/api';
import { useParams } from 'react-router-dom';

function Lesson() {
  const { id } = useParams();
  const [lesson, setLesson] = useState(null);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const loadLesson = async () => {
      const response = await fetchLesson(token, id);
      setLesson(response.data);
    };
    loadLesson();
  }, [token, id]);

  if (!lesson) return <div>Loading...</div>;
  return (
    <div>
      <h2>{lesson.title}</h2>
      <div>{lesson.content}</div>
    </div>
  );
}

export default Lesson;
