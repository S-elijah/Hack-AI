import React, { useEffect, useState } from 'react';
import { fetchQuizItems, submitQuizAnswer } from '../services/api';

function Quiz() {
  const [items, setItems] = useState([]);
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const loadItems = async () => {
      const response = await fetchQuizItems(token);
      setItems(response.data);
    };
    loadItems();
  }, [token]);

  if (items.length === 0) return <div>Loading quiz...</div>;

  const handleAnswer = async (answer) => {
    const result = await submitQuizAnswer(token, items[current].id, answer);
    if (result.data.correct) setScore(score + 1);
    if (current + 1 < items.length) {
      setCurrent(current + 1);
    } else {
      alert(`Quiz finished! Score: ${score + (result.data.correct ? 1 : 0)}/${items.length}`);
    }
  };

  return (
    <div>
      <h2>Quiz</h2>
      <div>{items[current].question}</div>
      {items[current].options.map((opt, idx) => (
        <button key={idx} onClick={() => handleAnswer(opt)}>
          {opt}
        </button>
      ))}
    </div>
  );
}

export default Quiz;
