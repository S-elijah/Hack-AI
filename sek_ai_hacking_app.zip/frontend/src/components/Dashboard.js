import React, { useEffect, useState } from 'react';
import { fetchLessons } from '../services/api';
import { Link } from 'react-router-dom';

function Dashboard() {
  const [lessons, setLessons] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
    const loadLessons = async () => {
      const response = await fetchLessons(token);
      setLessons(response.data);
    };
    loadLessons();
  }, [token]);

  return (
    <div>
      <h2>Dashboard</h2>
      <Link to="/quiz">Take Quiz</Link> | <Link to="/chat">AI Tutor</Link>
      <ul>
        {lessons.map((lesson, idx) => (
          <li key={idx}>
            <Link to={`/lesson/${lesson.id}`}>{lesson.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;
