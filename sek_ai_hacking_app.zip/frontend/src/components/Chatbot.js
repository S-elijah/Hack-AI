import React, { useState } from 'react';
import { chatWithAI } from '../services/api';

function Chatbot() {
  const [message, setMessage] = useState('');
  const [chat, setChat] = useState([]);
  const token = localStorage.getItem('token');

  const sendMessage = async () => {
    const response = await chatWithAI(token, message);
    setChat([...chat, { user: message, bot: response.data.reply }]);
    setMessage('');
  };

  return (
    <div>
      <h2>AI Tutor</h2>
      <div style={{ height: '300px', overflowY: 'scroll', border: '1px solid #ccc', padding: '10px' }}>
        {chat.map((c, idx) => (
          <div key={idx}>
            <p><strong>You:</strong> {c.user}</p>
            <p><strong>Bot:</strong> {c.bot}</p>
          </div>
        ))}
      </div>
      <input
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Ask the tutor..."
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}

export default Chatbot;
