import axios from 'axios';

const API_URL = 'http://localhost:8000';

export const signup = (username, email, password) => {
  return axios.post(`${API_URL}/auth/register`, { username, email, password });
};

export const login = (username, password) => {
  return axios.post(`${API_URL}/auth/token`, new URLSearchParams({
    username,
    password
  }));
};

export const fetchLessons = (token) => {
  return axios.get(`${API_URL}/lessons/`, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export const fetchLesson = (token, id) => {
  return axios.get(`${API_URL}/lessons/${id}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export const fetchQuizItems = (token) => {
  return axios.get(`${API_URL}/quiz/`, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export const submitQuizAnswer = (token, id, answer) => {
  return axios.post(`${API_URL}/quiz/submit`, { id, answer }, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

export const chatWithAI = (token, message) => {
  return axios.post(`${API_URL}/ai/`, { message }, {
    headers: { Authorization: `Bearer ${token}` }
  });
};
