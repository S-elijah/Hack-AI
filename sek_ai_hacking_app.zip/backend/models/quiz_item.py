from sqlalchemy import Column, Integer, String, Text
from core.database import Base

class QuizItem(Base):
    __tablename__ = "quiz_items"
    id = Column(Integer, primary_key=True, index=True)
    question = Column(Text, nullable=False)
    options = Column(Text, nullable=False)  # JSON string
    answer = Column(String, nullable=False)
