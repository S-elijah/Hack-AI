from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import auth, lessons, quiz, ai_chat
from core import config, database

app = FastAPI(title="SEK Tech Ethical Hacking Tutor")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(lessons.router, prefix="/lessons", tags=["lessons"])
app.include_router(quiz.router, prefix="/quiz", tags=["quiz"])
app.include_router(ai_chat.router, prefix="/ai", tags=["ai"])

# Create tables
database.Base.metadata.create_all(bind=database.engine)

@app.get("/")
def root():
    return {"message": "SEK Tech Ethical Hacking Tutor API"}

