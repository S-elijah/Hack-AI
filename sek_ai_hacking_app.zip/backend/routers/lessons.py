from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from core.database import get_db
from models.lesson import Lesson
from pydantic import BaseModel

router = APIRouter()

class LessonCreate(BaseModel):
    title: str
    content: str

@router.get("/", response_model=list[LessonCreate])
def get_lessons(db: Session = Depends(get_db)):
    lessons = db.query(Lesson).all()
    return lessons

@router.post("/", response_model=dict)
def create_lesson(lesson: LessonCreate, db: Session = Depends(get_db)):
    new = Lesson(title=lesson.title, content=lesson.content)
    db.add(new)
    db.commit()
    db.refresh(new)
    return {"msg": "Lesson added"}
