from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
import openai
from core.config import settings

router = APIRouter()
openai.api_key = settings.OPENAI_API_KEY

class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    reply: str

@router.post("/", response_model=ChatResponse)
async def chat(req: ChatRequest):
    prompt = f"You're an ethical hacking instructor. Guide the student with explanations and steps. They said: {req.message}"
    try:
        resp = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=500,
            temperature=0.7
        )
        reply = resp.choices[0].message.content
        return {"reply": reply}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
