from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from core.database import get_db
from models.quiz_item import QuizItem
from pydantic import BaseModel
import json

router = APIRouter()

class QuizItemCreate(BaseModel):
    question: str
    options: list[str]
    answer: str

class QuizItemOut(BaseModel):
    id: int
    question: str
    options: list[str]

@router.get("/", response_model=list[QuizItemOut])
def get_quiz_items(db: Session = Depends(get_db)):
    items = db.query(QuizItem).all()
    return [{"id": itm.id, "question": itm.question, "options": json.loads(itm.options)} for itm in items]

@router.post("/", response_model=dict)
def create_quiz_item(item: QuizItemCreate, db: Session = Depends(get_db)):
    options_str = json.dumps(item.options)
    new = QuizItem(question=item.question, options=options_str, answer=item.answer)
    db.add(new)
    db.commit()
    db.refresh(new)
    return {"msg": "Quiz item added"}

class QuizAnswer(BaseModel):
    id: int
    answer: str

@router.post("/submit", response_model=dict)
def submit_answer(ans: QuizAnswer, db: Session = Depends(get_db)):
    item = db.query(QuizItem).filter(QuizItem.id == ans.id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Quiz item not found")
    correct = item.answer == ans.answer
    return {"correct": correct}
